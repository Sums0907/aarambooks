# NDR Intelligence Domain — Master Architecture & Strategy

## 1. Executive Summary & Empirical Baseline
The NDR (Non-Delivery Report) Intelligence Domain is an autonomous revenue-protection engine designed to eliminate Return-to-Origin (RTO) losses in the AaramBooks ecosystem.

### Empirical Breakdown (Verified from 1,189 Live Store Records)

| Metric / Dimension | Store Reality | Percentage | Strategic Significance |
|---|---|---|---|
| **Total NDR Cases** | **1,189** | 100% | Full historical baseline in local DB |
| **Payment Mode: COD** | **1,087** | **91.4%** | Primary cash leak (two-way shipping loss) |
| **Payment Mode: Online / Prepaid** | **102** | 8.6% | Low RTO risk, priority delivery assistance |
| **Attempt 1 (Golden Window)** | **666** | **56.0%** | **Highest ROI:** 60-70% recoverable within 60 mins |
| **Attempt 2** | **216** | 18.2% | High urgency re-engagement |
| **Attempt 3 (Terminal Risk)** | **307** | 25.8% | Final dispute or RTO acknowledgement |

### Top Failure Mode Distribution

| Reason Code | Cases | Share | Core Problem | Designated Playbook |
|---|---|---|---|---|
| **Customer Unavailable / Unreachable** | 431 | 36.3% | Timing mismatch, work schedule | **Playbook A: Interactive WhatsApp / IVR** |
| **OTP Rejection / Buyer Remorse** | 333 | 28.0% | Customer hesitation, second thoughts | **Playbook C: 10% UPI Conversion Incentive** |
| **No Attempt / Exception (Fake Attempt)** | 235 | 19.8% | Delivery executive skipped doorstep | **Playbook B: Doorstep Verification & Courier Dispute** |
| **Delivery Rescheduled** | 89 | 7.5% | Customer requested later date | **Playbook A: Automated Date Commitment** |
| **Address Incomplete / Issue** | 101 | 8.4% | Landmark missing, wrong pincode | **Playbook D: Landmark & Maps Link Capture** |

---

## 2. The 3-Tier Defense Architecture

```mermaid
graph TD
    subgraph Tier1["Tier 1: Pre-Dispatch Defense"]
        T1_A["Address Quality Scoring"] --> T1_B["COD Intent Verification"]
    end

    subgraph Tier2["Tier 2: Golden Hour Triage (Attempt 1)"]
        T2_A["NDR Detected in Sync"] --> T2_B{"Golden Hour Window (<60 min)?"}
        T2_B -->|Yes| T2_C["Instant WhatsApp Interactive Flow"]
        T2_B -->|No Response (T+45m)| T2_D["Smart IVR Voice Call Fallback"]
    end

    subgraph Tier3["Tier 3: Carrier Escalation & Reattempt"]
        T3_A["Customer Confirms Reattempt Date"] --> T3_B["ShopDeck Reattempt Injection"]
        T3_C["Customer Flags Fake Attempt"] --> T3_D["Courier Dispute & Escalation"]
    end

    Tier1 --> Tier2 --> Tier3
```

---

## 3. Data Assembly (The `NDRCaseContext`)

The engine never feeds raw SQL rows to the LLM. It queries the local ShopDeck Public Read Views and synthesizes a structured **`NDRCaseContext`**.

### The 4-Way Join Strategy (Keyed on `awb_no`)

```mermaid
erDiagram
    vw_shopdeck_shipment_ndr_reports ||--o{ vw_shopdeck_ndr_action_log : "1:N (awb_no, ndr_count)"
    vw_shopdeck_shipment_ndr_reports ||--|| vw_shopdeck_customer_info : "1:1 (awb_no)"
    vw_shopdeck_shipment_ndr_reports ||--o{ vw_shopdeck_order_line_items : "1:N (awb_no / order_id)"

    vw_shopdeck_shipment_ndr_reports {
        string awb_no PK
        string latest_ndr_reason
        timestamp latest_ndr_time
        int ndr_count
        string courier_partner
        string order_status
    }
    vw_shopdeck_customer_info {
        string awb_no FK
        string customer_number "Decrypted phone"
        string customer_name
        string drop_city
        string drop_pincode
    }
    vw_shopdeck_ndr_action_log {
        string _id PK
        string awb_no FK
        string action_type
        string response_status
        timestamp action_time
    }
    vw_shopdeck_order_line_items {
        string order_id PK
        string awb_no FK
        string product_name
        float selling_price
        string payment_mode
    }
```

### 3.1 Formal `NDRCaseContext` Schema (Pydantic / Python Model):
```python
from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime

class NDROutreachHistory(BaseModel):
    action_type: str            # 'ivr_call', 'sms', 'hsm', 'call'
    action_time: datetime
    response_status: Optional[str] # 'completed', 'no-answer', 'positive', 'negative'
    remarks: Optional[str]
    call_duration_seconds: Optional[int]

class NDRCaseContext(BaseModel):
    # Identifiers & Shipment
    awb_no: str
    order_id: str
    courier_partner: str
    
    # Customer Details
    customer_id: str
    customer_name: str
    customer_phone: str         # Decrypted contact number
    delivery_city: str
    delivery_pincode: str
    
    # Financials & Items
    payment_mode: str           # 'cod', 'prepaid', 'partial-cod'
    total_order_value: float
    items: List[str]            # E.g. ['Bhagavad Gita As It Is', 'Srimad Bhagavatam']
    
    # NDR Status & Attempt Sequence
    ndr_count: int              # Attempt 1, 2, or 3
    ofd_count: int              # Out for delivery count
    latest_ndr_reason: str      # 'customer unavailable', 'no attempt', etc.
    latest_ndr_time: datetime
    
    # Historical Timeline
    outreach_history: List[NDROutreachHistory] = Field(default_factory=list)
    
    # Computed Intelligence Flags
    is_golden_hour: bool        # True if within 60 mins of latest_ndr_time
    suspected_fake_attempt: bool # True if 'no attempt' or high discrepancy
    priority_score: int         # 1 (Highest) to 5 (Lowest) based on Value + Attempt
```

---

## 4. The 4 Reason-Specific Autonomous Playbooks

```mermaid
flowchart TD
    Start([NDR Event Detected]) --> ReasonCheck{NDR Reason Code}

    ReasonCheck -->|Customer Unavailable| PlaybookA[Playbook A: Interactive WhatsApp / IVR]
    ReasonCheck -->|Fake Attempt / No Attempt| PlaybookB[Playbook B: Doorstep Verification Loop]
    ReasonCheck -->|OTP Rejection / Buyer Remorse| PlaybookC[Playbook C: 10% UPI Discount Incentive]
    ReasonCheck -->|Address Incomplete| PlaybookD[Playbook D: Landmark & Maps Link Capture]

    PlaybookA --> Action_Reattempt[Commit Reattempt Date to ShopDeck]
    PlaybookB --> Action_Dispute[File Carrier Dispute + Escalation]
    PlaybookC --> Action_Convert[Convert to Prepaid & Reschedule]
    PlaybookD --> Action_Address[Enrich Address in Customer Record]
```

### Playbook Details Table

| Playbook | Target Reason | Trigger Window | Communication Channel | Customer Action Options | Target Outcome |
|---|---|---|---|---|---|
| **A: Scheduler** | `customer unavailable`, `unreachable` | T+0 min (WhatsApp), T+45 min (IVR) | WhatsApp Interactive HSM / IVR DTMF | `[Tomorrow]` `[Day After]` `[Change Address]` | Commit valid `reattempt_date` |
| **B: Fake Buster** | `no attempt`, `exception` | T+0 min | WhatsApp 2-Way Check | `[Yes, I was busy]` `[No, nobody came]` | Log dispute against carrier; demand reattempt |
| **C: Remorse Rescue** | `otp-based cancellation`, `rejected` | T+0 min to T+30 min | WhatsApp Rich Media + Payment Link | `[Pay via UPI (10% Off)]` `[Keep COD]` `[Cancel]` | Convert COD ➔ Prepaid (98%+ delivery rate) |
| **D: Address Fix** | `address issue`, `incomplete` | T+0 min | WhatsApp Text & Location Request | Enter landmark or share WhatsApp Live Location | Append landmark to manifest |

---

## 5. Multi-Channel Communication Matrix & SLAs

| Channel | Trigger SLA | Engagement Cost | Response Rate Benchmark | Best Suited For |
|---|---|---|---|---|
| **WhatsApp HSM (Interactive)** | **T+0 to T+15 min** | ~₹0.50 | 45%–55% | Fast, button-based date selection & payment links |
| **Smart IVR Voice Call** | **T+45 min (Fallback)** | ~₹0.40 / min | 60%–70% | Urgent outreach when customer doesn't read WhatsApp |
| **SMS Backup (TinyURL)** | **T+60 min** | ~₹0.15 | 10%–15% | Fallback for feature phones without WhatsApp |

---

## 6. Closed-Loop Execution Workflow

```mermaid
sequenceDiagram
    autonumber
    participant ShopDeck as ShopDeck Local DB
    participant Engine as NDR Intelligence Domain
    participant Comm as WhatsApp / IVR Gateway
    participant Customer as Customer Phone
    participant Carrier as Courier Partner API

    ShopDeck->>Engine: Detects new NDR (Attempt 1, COD)
    Engine->>Engine: Assembles NDRCaseContext & evaluates Playbook
    Engine->>Comm: Dispatches Interactive WhatsApp Message
    Comm->>Customer: Delivers options (Tomorrow / Day After)
    Customer-->>Comm: Selects "Tomorrow"
    Comm->>Engine: Returns response event
    Engine->>ShopDeck: Updates ndr_action_log & reattempt_date
    Engine->>Carrier: Pushes reattempt request to courier queue
```
